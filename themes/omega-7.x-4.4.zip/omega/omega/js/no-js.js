(function ($) {
  $('html').removeClass('no-js');
})(jQuery);
